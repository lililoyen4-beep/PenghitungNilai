PENGHITUNG NILAI - PROYEK ANDROID

Aplikasi ini membungkus Penghitung Nilai dalam Android WebView.
Data disimpan secara lokal di perangkat melalui localStorage WebView.

MEMBUAT APK OTOMATIS (TANPA ANDROID STUDIO):
1. Buat akun / masuk ke https://github.com
2. Buat repository baru, misalnya "PenghitungNilai".
3. Upload seluruh isi folder PenghitungNilaiAndroid ke repository (termasuk folder .github).
4. Buka tab Actions pada repository.
5. Pilih workflow "Build APK", lalu tekan "Run workflow" (atau tunggu build otomatis setelah push).
6. Setelah selesai dan status hijau, buka hasil run tersebut.
7. Di bagian Artifacts, unduh "Penghitung-Nilai-APK".
8. Ekstrak ZIP artifact, lalu pasang app-debug.apk di HP Android.
   Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

MEMBUAT APK DENGAN ANDROID STUDIO:
1. Buka folder PenghitungNilaiAndroid di Android Studio.
2. Tunggu Gradle Sync.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. File APK ada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
- Folder ini adalah proyek sumber, bukan APK yang sudah dikompilasi.
- APK debug cocok untuk pemasangan pribadi dan pengujian.
- Data aplikasi tersimpan di perangkat. Jangan hapus data aplikasi atau uninstall jika ingin mempertahankan data lokal.
- Ekspor CSV secara berkala sebagai cadangan.
