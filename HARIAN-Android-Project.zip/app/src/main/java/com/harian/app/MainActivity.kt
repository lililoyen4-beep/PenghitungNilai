package com.harian.app

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Task(val id: Long, var title: String, var time: String, var done: Boolean)

class MainActivity : Activity() {
    private val tasks = mutableListOf<Task>()
    private lateinit var list: LinearLayout
    private lateinit var progressText: TextView
    private lateinit var progressBar: View
    private val green = Color.rgb(22, 132, 91)
    private val ink = Color.rgb(31, 42, 36)
    private val muted = Color.rgb(112, 124, 116)
    private val prefs by lazy { getSharedPreferences("harian_data", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadTasks()
        buildScreen()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(245, 247, 245))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        content.addView(text("HARIAN", 15f, green, true).apply {
            letterSpacing = 0.12f
            setPadding(0, 0, 0, dp(18))
        })
        content.addView(text("Selamat datang! 👋", 26f, ink, true))
        content.addView(text("Atur kegiatanmu, jalani harimu.", 14f, muted).apply {
            setPadding(0, dp(5), 0, dp(20))
        })

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.WHITE, 18)
        }
        val summaryRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        summaryRow.addView(text("Progres hari ini", 15f, ink, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        progressText = text("0/0", 15f, green, true)
        summaryRow.addView(progressText)
        summary.addView(summaryRow)
        val track = View(this).apply {
            background = rounded(Color.rgb(229, 236, 231), 10)
        }
        val trackParams = LinearLayout.LayoutParams(-1, dp(8)).apply {
            topMargin = dp(13)
        }
        summary.addView(track, trackParams)
        progressBar = View(this).apply { background = rounded(green, 10) }
        summary.addView(progressBar, LinearLayout.LayoutParams(0, dp(8)))
        content.addView(summary)

        val heading = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(12))
        }
        heading.addView(text("Daftar kegiatan", 19f, ink, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(heading)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        val add = Button(this).apply {
            text = "+ Tambah kegiatan"
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(green, 14)
            setOnClickListener { showTaskDialog(null) }
        }
        content.addView(add, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(16)
        })

        content.addView(text("Data tersimpan di perangkat ini.", 12f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(8))
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderTasks()
    }

    private fun renderTasks() {
        list.removeAllViews()
        if (tasks.isEmpty()) {
            val empty = text("Belum ada kegiatan. Tambahkan rencanamu!", 14f, muted)
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(12), dp(24), dp(12), dp(24))
            list.addView(empty)
        }
        tasks.sortedWith(compareBy<Task>({ it.time }, { it.id })).forEach { task ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(8), dp(10))
                background = rounded(Color.WHITE, 14)
            }
            val check = CheckBox(this).apply {
                isChecked = task.done
                buttonTintList = android.content.res.ColorStateList.valueOf(green)
                setOnCheckedChangeListener { _, checked ->
                    task.done = checked
                    saveTasks()
                    updateProgress()
                    renderTasks()
                }
            }
            card.addView(check)
            val labels = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), 0, dp(4), 0)
            }
            labels.addView(text(task.title, 15f, if (task.done) muted else ink, true))
            labels.addView(text(task.time, 12f, muted).apply {
                setPadding(0, dp(3), 0, 0)
            })
            card.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val edit = TextView(this).apply {
                text = "⋮"
                textSize = 24f
                setTextColor(muted)
                gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(8), 0)
                setOnClickListener { showTaskOptions(task) }
            }
            card.addView(edit)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(9)
            })
        }
        updateProgress()
    }

    private fun updateProgress() {
        val done = tasks.count { it.done }
        progressText.text = "$done/${tasks.size}"
        val parent = progressBar.layoutParams
        val ratio = if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size
        progressBar.post {
            val total = (progressBar.parent as? View)?.width ?: 0
            progressBar.layoutParams = LinearLayout.LayoutParams((total * ratio).toInt(), dp(8))
        }
    }

    private fun showTaskDialog(existing: Task?) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply {
            hint = "Contoh: Belajar, olahraga, membaca"
            setText(existing?.title ?: "")
            textSize = 15f
        }
        val timeButton = Button(this).apply {
            isAllCaps = false
            text = "Pilih jam: ${existing?.time ?: "08:00"}"
        }
        var selectedTime = existing?.time ?: "08:00"
        timeButton.setOnClickListener {
            val parts = selectedTime.split(":")
            TimePickerDialog(this, { _, hour, minute ->
                selectedTime = String.format("%02d:%02d", hour, minute)
                timeButton.text = "Pilih jam: $selectedTime"
            }, parts[0].toInt(), parts[1].toInt(), true).show()
        }
        panel.addView(name)
        panel.addView(timeButton)
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Tambah kegiatan" else "Ubah kegiatan")
            .setView(panel)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val title = name.text.toString().trim()
                if (title.isNotEmpty()) {
                    if (existing == null) tasks.add(Task(System.currentTimeMillis(), title, selectedTime, false))
                    else {
                        existing.title = title
                        existing.time = selectedTime
                    }
                    saveTasks()
                    renderTasks()
                }
            }.show()
    }

    private fun showTaskOptions(task: Task) {
        AlertDialog.Builder(this)
            .setTitle(task.title)
            .setItems(arrayOf("Ubah kegiatan", "Hapus kegiatan")) { _, which ->
                if (which == 0) showTaskDialog(task)
                else AlertDialog.Builder(this)
                    .setMessage("Hapus kegiatan ini?")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        tasks.remove(task)
                        saveTasks()
                        renderTasks()
                    }.show()
            }.show()
    }

    private fun saveTasks() {
        val array = JSONArray()
        tasks.forEach {
            array.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("time", it.time)
                put("done", it.done)
            })
        }
        prefs.edit().putString("tasks", array.toString()).apply()
    }

    private fun loadTasks() {
        val raw = prefs.getString("tasks", null) ?: return
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                tasks.add(Task(
                    obj.optLong("id", i.toLong()),
                    obj.optString("title"),
                    obj.optString("time", "08:00"),
                    obj.optBoolean("done", false)
                ))
            }
        } catch (_: Exception) {
            tasks.clear()
        }
    }
}
