# HARIAN — Aplikasi Kegiatan Sehari-hari

Aplikasi Android sederhana untuk mencatat kegiatan harian secara offline.

## Fitur versi awal
- Tambah kegiatan dan jam
- Tandai kegiatan selesai
- Lihat progres kegiatan
- Ubah dan hapus kegiatan
- Simpan data di perangkat menggunakan SharedPreferences
- Tidak memerlukan akun atau internet

## Membuat APK melalui GitHub
1. Buat repository GitHub baru bernama `HARIAN`.
2. Upload seluruh isi folder proyek ini ke root repository (jangan upload ZIP di dalam ZIP).
3. Buka tab **Actions**.
4. Pilih workflow **Build APK HARIAN**.
5. Tekan **Run workflow**.
6. Setelah selesai, unduh artifact **HARIAN-APK**.
7. Ekstrak ZIP artifact dan pasang `app-debug.apk` di Android.

## Catatan
Ini adalah APK debug untuk uji coba. Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.
